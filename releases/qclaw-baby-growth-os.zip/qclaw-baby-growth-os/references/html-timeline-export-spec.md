# HTML 时间轴导出规格

HTML 时间轴是本地轻量版的展示层，用于把珍贵记录变成可浏览、可分享、可长期保存的本地网站。

## 输入

读取本地轻量版数据：

```text
ChildGrowthOS/
├── data/
│   ├── daily-journal.jsonl
│   ├── photo-assets.jsonl
│   ├── milestones.jsonl
│   ├── health.jsonl
│   └── knowledge-mapping.jsonl
└── photos/
```

## 输出

```text
ChildGrowthOS/
└── exports/
    └── html-timeline/
        ├── index.html
        ├── assets/
        │   ├── styles.css
        │   └── app.js
        └── data/
            └── timeline-data.json
```

## 页面结构

首页就是时间轴，不做营销落地页。

必要模块：

- 顶部：宝宝昵称、年龄范围、照片数量、里程碑数量。
- 筛选：年份、月龄、事件类型、关键词。
- 时间轴：按日期倒序或正序展示事件卡片。
- 照片卡：显示首图、标题、故事、标签、关联照片数。
- 第一次合集：筛选重要里程碑。
- 健康档案入口：只在本地显示，不默认分享。

## 卡片字段

每张时间轴卡片包含：

- 日期
- 宝宝年龄
- 标题
- 事件类型
- AI成长故事
- 父母原话
- 首图
- 关联照片
- 标签

## 隐私与分享

默认生成本地静态网站，不上传外网。

如果要分享给亲友，应支持：

- 隐藏健康记录。
- 隐藏父母原话。
- 只导出精选照片。
- 按年份导出。

## 图片引用

HTML 使用相对路径引用照片：

```html
<img src="../../photos/2026/08/20260802_7M1D_first-watermelon_baby_happy_P202608020001.jpg" alt="第一次吃西瓜">
```

只要保持 `exports/` 和 `photos/` 在同一个 `ChildGrowthOS/` 目录下，图片就能离线显示。
