# Setup Guide

## Prerequisites

1. QClaw/OpenClaw can load local skills.
2. Local Lite only requires local file access.
3. Feishu sync requires the Feishu official plugin to be installed and authorized.
4. Dual backup requires both local file access and Feishu authorization.

## Import

Import the whole `qclaw-baby-growth-os` folder or its zip package as a local skill.

Required file:

- `SKILL.md`

Supporting files:

- `references/feishu-base-schema.json`
- `references/parsing-contract.md`
- `references/setup-guide.md`
- `references/knowledge-push-design.md`

## First Command

Send this to QClaw:

For non-technical users, use Local Lite first:

```text
使用晖爸育儿系统技能，帮我创建一个本地轻量版孩子成长记录。
宝宝昵称：小晖
生日：2026-01-01
保存位置：桌面/BabyGrowthOS
同步模式：只保存本地
```

For dual backup:

```text
使用晖爸育儿系统技能，帮我创建晖爸育儿系统双备份档案。
先保存到本地 BabyGrowthOS 文件夹，再同步到飞书。
宝宝昵称：小晖
生日：2026-01-01
```

For Feishu-only advanced setup:

```text
使用晖爸育儿系统技能，帮我创建一个新的飞书多维表格育儿系统。
宝宝昵称：小晖
生日：2026-01-01
记录人：爸爸
```

## Daily Record Examples

```text
今天宝宝6个月12天，第一次吃香蕉泥，很喜欢，没有过敏，还拍了两张照片。
```

微信发图测试：

```text
今天第一次吃西瓜，宝宝吃得很开心。
```

同时发送 1-2 张吃西瓜照片。系统应该先回复“收到，写入中”。本地模式下保存到 `photos/YYYY/MM/` 并在 Excel 里写入可点击链接；飞书模式下再把照片作为附件写入 `照片资产库.原始文件`，并把照片链接到 `每日成长日记`、`喂养记录` 和 `成长时间轴`。

```text
上午9点换尿片，有小便，大便一次，黄色糊状，拍了照片。
```

```text
帮我记为待办，明天提醒一下买奶粉。
```

```text
这条微信是昨天晚上发的：今天第一次吃西瓜，宝宝很开心。请按微信发送时间记录，不要记到今天。
```

```text
昨晚宝宝睡了10小时，夜醒1次，比前几天好多了。
```

```text
今天体检，体重8.1kg，身高68cm，医生说发育正常。
```

微信医疗单据测试：

```text
今天去医院看医生，这是医生开的单子和用药说明，帮我存一下。
```

同时发送单据照片。本地模式下应保存到 `photos/YYYY/MM/` 并在 Excel 里链接到健康记录；飞书模式下应把照片作为附件写入 `照片资产库`，并链接到 `健康档案.关联照片`。

```text
爸爸想记录一句话：今天你第一次自己坐稳，我真的很激动。
```

## Expected Behavior

QClaw should:

1. Parse the message.
2. If the message comes from WeChat, reply immediately with a short acknowledgement.
3. Download WeChat photos/files.
4. In local mode, save photos to `photos/YYYY/MM/` and write relative links to Excel.
5. In Feishu mode, upload photos to `照片资产库.原始文件` as Feishu attachments.
6. Write one daily journal.
7. Write specialized records when needed.
8. Link photo asset records to daily journal, milestone, feeding, sleep, diaper, health, body growth, or family-letter records as relevant.
9. Update reverse links on the photo asset records.
10. Create milestones only when meaningful.
11. Update baby current state.
12. For WeChat inputs, interpret today/yesterday/tomorrow by the message sent time and check the dedupe key before writing.
13. Create parenting todos/reminders only when explicitly requested.
14. Reply with a compact write summary.

## WeChat Date and Duplicate Test

If QClaw receives a WeChat message from yesterday but processes it today, it must use the WeChat sent time.

Example:

```text
消息ID=abc123
微信发送时间=2026-08-15 21:10
Agent执行时间=2026-08-16 08:30
内容=今天第一次吃西瓜，宝宝很开心
```

Expected:

- `记录归属日期=2026-08-15`
- `去重键` is generated.
- If `abc123` was already completed, do not write duplicate journal or event records.

## Todo Reminder Test

```text
帮我记为待办，明天提醒一下买奶粉。
```

Expected:

- Create `育儿待办提醒`.
- Category is `采购`.
- Reminder date is tomorrow relative to WeChat sent time when from WeChat.
- Reply with the reminder time.

## Local Lite Files

Local Lite creates:

```text
ChildGrowthOS/
├── ChildGrowthOS.xlsx
├── data/
├── photos/
│   ├── originals/
│   │   └── YYYY/
│   │       └── MM/
│   └── YYYY/
│       └── MM/
├── exports/
└── logs/
```

Photo filename:

```text
YYYYMMDD_AGE_EVENT_SUBJECT_EMOTION_ASSETID.ext
```

Example:

```text
20260802_7M1D_first-watermelon_baby_happy_P202608020001.jpg
```

Excel can open photos through relative `HYPERLINK()` formulas as long as the workbook and `photos/` folder stay together.

## Daily 21:00 Review

Create an enabled `知识推送计划`:

- 计划名称：每日 21 点成长日记复盘
- 推送类型：日记复盘
- 推送渠道：微信
- 推送时间：21:00
- 启用状态：启用

At 21:00, QClaw should summarize today's saved records and ask whether the parent wants to add anything. If the parent replies, append the supplement to `每日成长日记.晚间补充` and update `晚间复盘状态=已补充`.

## Child Skill Hub Test

After configuring GitHub:

```text
检查晖爸 0-18 岁成长知识库有没有新的子技能适合我家宝宝。
```

Expected behavior:

1. Read `releases/latest.json`.
2. Read `skills-manifest.json`.
3. Compare baby age and recent records.
4. Recommend relevant skills through WeChat.
5. Do not install until the user explicitly replies, such as:

```text
安装英语启蒙
```

If installation succeeds, write or update `已安装子技能`.
