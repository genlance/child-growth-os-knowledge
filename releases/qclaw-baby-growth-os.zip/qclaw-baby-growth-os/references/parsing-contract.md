# Parsing Contract

Use this contract whenever parents send natural-language baby records.

## Output JSON

```json
{
  "date": "YYYY-MM-DD or null",
  "baby_name": "string or null",
  "baby_age": "computed or mentioned age, e.g. 6M12D",
  "recorder": "爸爸|妈妈|家人|unknown",
  "source_channel": "wechat|feishu|manual|unknown",
  "source_message_id": "string or null",
  "source_session_id": "string or null",
  "source_sender_id": "string or null",
  "message_sent_at": "ISO datetime from WeChat metadata or null",
  "agent_processed_at": "ISO datetime or null",
  "record_date": "YYYY-MM-DD; computed from explicit date text or message_sent_at",
  "dedupe_key": "source_channel + source_message_id, or sender + sent_at + text/media hash",
  "duplicate_check": {
    "status": "not_checked|first_message|suspected_duplicate|confirmed_duplicate|allow_rewrite",
    "matched_task_id": "string or null",
    "should_skip_write": false
  },
  "quick_ack": {
    "should_ack_first": true,
    "ack_text": "收到：...我先帮你写入飞书，照片会作为附件保存，稍后同步结果告诉你。"
  },
  "original_text": "parent raw message",
  "intents": [
    "daily_journal",
    "photo",
    "milestone",
    "feeding",
    "sleep",
    "diaper",
    "health",
    "body_growth",
    "knowledge_mapping",
    "family_letter",
    "todo"
  ],
  "daily_journal": {
    "title": "short Chinese title",
    "story": "warm factual story",
    "keywords": [],
    "emotions": [],
    "importance": "普通|珍贵|里程碑",
    "cover_photo_hint": "which photo should be cover"
  },
  "photos": [
    {
      "original_filename": "string or null",
      "source_media_id": "wechat media/file id or null",
      "local_download_required": true,
      "feishu_attachment_required": true,
      "asset_filename": "YYYYMMDD_AGE_EVENT_SUBJECT_EMOTION.ext",
      "event_type": "日常|第一次|喂养|睡眠|尿片|健康|运动发展|语言发展|亲子|旅行|家庭",
      "people": [],
      "emotion": "开心|好奇|兴奋|平静|哭闹|困倦|未知",
      "description": "visual description",
      "importance": "普通|精选|封面候选|里程碑",
      "link_targets": {
        "daily_journal": true,
        "milestone_index": [],
        "feeding_index": [],
        "sleep": false,
        "diaper_index": [],
        "health_index": [],
        "body_growth": false,
        "family_letter": false
      }
    }
  ],
  "feeding": [
    {
      "feeding_type": "母乳|奶粉|混合|辅食|饮水|其他",
      "milk_ml": null,
      "count": null,
      "solid_food": "string or null",
      "first_time": false,
      "allergy_reaction": "无|轻微|明显|待观察|未知",
      "preference": "喜欢|一般|不喜欢|未知",
      "notes": "",
      "photo_hints": []
    }
  ],
  "sleep": {
    "bedtime": null,
    "wake_time": null,
    "nap_count": null,
    "nap_hours": null,
    "night_wake_count": null,
    "total_sleep_hours": null,
    "quality": "很好|正常|偏差|很差|未知",
    "notes": "",
    "photo_hints": []
  },
  "diaper": [
    {
      "time": "HH:mm or null",
      "pee": true,
      "poop": false,
      "poop_count": null,
      "poop_texture": "水样|稀便|糊状|成形|干硬|有黏液|带血丝|未知",
      "poop_color": "黄色|金黄|绿色|棕色|黑色|红色|白灰色|未知",
      "urine_volume": "少|正常|多|未知",
      "urine_color": "清亮|浅黄|深黄|橙红|未知",
      "diaper_rash": "无|轻微|明显|未知",
      "photo_hint": "string or null",
      "notes": "",
      "safety_level": "记录即可|需要观察|建议咨询医生|建议及时就医"
    }
  ],
  "health": [
    {
      "event_name": "string",
      "event_type": "发烧|咳嗽|腹泻|过敏|疫苗|体检|用药|意外|其他",
      "symptoms": "",
      "temperature_c": null,
      "vaccine_name": null,
      "doctor_or_hospital": "string or null",
      "handling": "",
      "safety_level": "记录即可|需要观察|建议咨询医生|建议及时就医",
      "photo_hints": []
    }
  ],
  "body_growth": {
    "height_cm": null,
    "weight_kg": null,
    "head_circumference_cm": null,
    "source": "家庭测量|体检|医院|其他",
    "photo_hints": []
  },
  "milestones": [
    {
      "name": "第一次吃香蕉泥",
      "category": "身体发展|语言发展|认知发展|情感发展|社交发展|生活能力|家庭事件|旅行|健康",
      "is_first_time": true,
      "story": "",
      "meaning": "",
      "importance": "普通节点|重要节点|人生第一次"
    }
  ],
  "knowledge_mapping": [
    {
      "topic": "string",
      "applicable_stage": "string",
      "trigger": "string",
      "recommendation": "cautious suggestion",
      "needs_followup_result": true
    }
  ],
  "todos": [
    {
      "title": "购买奶粉",
      "category": "采购|健康预约|疫苗/体检|观察跟进|亲子活动|资料准备|其他",
      "priority": "低|中|高|紧急",
      "due_date": "YYYY-MM-DD or null",
      "reminder_at": "ISO datetime or null",
      "repeat_rule": "不重复|每天|每周|每月|自定义",
      "reminder_channels": ["微信"],
      "source": "微信用户输入|知识推送|健康记录|喂养记录|系统建议|手动创建",
      "reminder_text": "明天提醒我买奶粉",
      "linked_knowledge_push_id": "string or null",
      "linked_knowledge_topic": "string or null",
      "needs_confirmation": false
    }
  ],
  "needs_user_confirmation": false,
  "confirmation_questions": [],
  "evening_review": {
    "is_review_reply": false,
    "append_to_daily_journal": false,
    "supplement_text": "string or null",
    "new_photo_hints": []
  }
}
```

## WeChat Date and Deduplication Rules

For WeChat inputs, the message metadata is part of the data.

1. Always read `message_sent_at` from WeChat before interpreting words like `今天`, `昨天`, `明天`, `上午`, `晚上`.
2. If the user says `今天`, it means the date of `message_sent_at`, not the date the agent happens to run.
3. If the user says `昨天`, subtract one day from `message_sent_at`.
4. If the user says `明天提醒`, add one day to `message_sent_at`.
5. If no date phrase exists, set `record_date` to the date of `message_sent_at`.
6. Before writing records, search existing `微信写入任务` by `dedupe_key`.
7. If a matching task is completed or partially completed, set `should_skip_write=true` and do not create duplicate journal/event records.
8. If the same old WeChat message is replayed by the channel, reply: `这条微信消息之前已经记录过了，我不会重复写入。`

Never use the current agent runtime date as a substitute for missing WeChat sent time. If `message_sent_at` is unavailable and date matters, ask the user to confirm the record date.

## Todo Extraction Rules

Create todos when the parent explicitly asks for a reminder or todo:

- `帮我记为待办`
- `明天提醒一下`
- `提醒我买奶粉`
- `记得买宝宝衣服`
- `下周约体检`
- `两天后提醒我观察大便`

Relative reminder dates must be computed from `message_sent_at` for WeChat messages.

If a knowledge push suggests an action, do not create a todo unless the parent replies with a clear instruction such as `帮我记为待办，明天提醒一下`.

Examples:

```json
{
  "message_sent_at": "2026-08-16T21:30:00+08:00",
  "original_text": "帮我记为待办，明天提醒一下买奶粉",
  "intents": ["todo"],
  "todos": [
    {
      "title": "购买奶粉",
      "category": "采购",
      "priority": "中",
      "due_date": "2026-08-17",
      "reminder_at": "2026-08-17T09:00:00+08:00",
      "repeat_rule": "不重复",
      "reminder_channels": ["微信"],
      "source": "微信用户输入",
      "reminder_text": "提醒购买奶粉",
      "needs_confirmation": false
    }
  ]
}
```

## Attachment and Link Rules

For every WeChat image/video/file:

1. Download the original media file from the message channel.
2. Upload it to Feishu into `照片资产库.原始文件` as an attachment.
3. Create the photo asset record only after the attachment upload succeeds, or mark `附件上传状态=上传失败`.
4. Return the created `照片资产库` record id.
5. Write that record id into the relevant event table's photo link field.
6. Update the reverse link fields on `照片资产库`.

Examples:

- Doctor order, prescription, vaccine booklet, test report -> `健康档案.关联照片` and `照片资产库.关联健康`.
- First food / first movement / birthday / trip -> `成长时间轴.关联照片` and `照片资产库.关联里程碑`.
- Food photo -> `喂养记录.关联照片` and optionally `成长时间轴.关联照片` if it is a first.
- Sleeping photo -> `睡眠记录.关联照片`.
- Diaper photo -> `尿片记录.照片`.

If the attachment field cannot be written, do not report the photo as saved. Report it as metadata saved but attachment upload incomplete.

## Confirmation Rules

Ask before writing when:

- The date is unclear and cannot be inferred from message time.
- There are multiple babies and baby name is unclear.
- A health event may be urgent.
- A photo's event label is uncertain but will become a milestone.
- User asks to delete or overwrite existing records.

## Milestone Rules

Create a milestone only for:

- First-time events.
- Clear developmental breakthroughs.
- Meaningful family memories.
- Health/vaccine/checkup nodes worth future reference.
- Travel/school/social milestones.

Do not create milestones for ordinary daily milk/sleep/poop records unless the user marks them important.
