# 本地轻量版存储方案

本地轻量版是晖爸育儿系统的默认入门方案，目标是让小白用户只需要打开电脑、运行 QClaw/WorkBuddy，就能开始保存孩子成长记录和家庭育儿资料。

## 核心判断

默认使用 Excel 工作簿作为家长可见入口，同时保留 Agent 友好的本地数据文件。

```text
ChildGrowthOS/
├── ChildGrowthOS.xlsx
├── data/
│   ├── baby-profile.json
│   ├── daily-journal.jsonl
│   ├── photo-assets.jsonl
│   ├── milestones.jsonl
│   ├── feeding.jsonl
│   ├── sleep.jsonl
│   ├── diaper.jsonl
│   ├── health.jsonl
│   ├── body-growth.jsonl
│   ├── todos.jsonl
│   └── knowledge-mapping.jsonl
├── photos/
│   ├── originals/
│   │   └── 2026/
│   │       └── 08/
│   └── 2026/
│       └── 08/
├── exports/
│   ├── html-timeline/
│   └── reports/
└── logs/
    ├── write-tasks.jsonl
    ├── wechat-write-tasks.jsonl
    └── sync-history.jsonl
```

## 为什么用 Excel

- 大众熟悉，双击就能打开。
- 多张表比一堆 CSV 更容易理解。
- 可以用 `HYPERLINK()` 点击跳转到本地照片。
- 可以复制给家人，也可以定期导出。
- 后续仍能同步到飞书或生成 HTML 网站。

Excel 不是唯一数据源。Agent 应优先把结构化记录写入 `data/*.jsonl`，再刷新 `ChildGrowthOS.xlsx`。这样即使 Excel 被用户手工改坏，原始结构化数据仍可恢复。

## 本地照片命名

照片文件名必须稳定、可排序、可读、可迁移。

推荐格式：

```text
YYYYMMDD_AGE_EVENT_SUBJECT_EMOTION_ASSETID.ext
```

示例：

```text
20260802_6M12D_first-watermelon_baby_happy_P202608020001.jpg
20260802_6M12D_doctor-prescription_hospital_record_P202608020002.jpg
```

说明：

- `YYYYMMDD`：事件日期。
- `AGE`：宝宝年龄，如 `6M12D`、`2Y03M`。
- `EVENT`：短事件标签，建议英文 slug，避免跨平台乱码。
- `SUBJECT`：主体，如 `baby`、`father-baby`、`hospital-record`。
- `EMOTION`：情绪或用途，如 `happy`、`curious`、`checkup`。
- `ASSETID`：唯一资产编号，防重名。

Excel 里保留中文标题和中文描述，文件名尽量用 ASCII，便于 Windows、GitHub、HTML、备份软件长期兼容。

## 批量照片命名防错

批量处理照片时，Agent 必须先生成“媒体清单”，再命名。清单至少包含：

- `source_path` / `source_filename`
- `source_order`
- `file_size`
- `modified_time` 或微信消息顺序
- `checksum_short`
- `asset_id`
- `content_summary`
- `proposed_filename`
- `confidence`

命名必须按清单逐张执行，不能先让 AI 输出一组照片描述，再把描述按列表顺序套回文件。Windows 文件夹、下载缓存和 Agent 运行时目录的排序可能不同，容易造成“文件名写的是小院散步，打开却是客厅照片”。

如果识别或匹配置信度不足，宁可使用保守文件名：

```text
20260820_AGE_photo-baby_P202608200003.jpg
```

并在 `照片资产库.状态` 标记为 `待确认`。不要为了名字好看而编一个可能属于另一张照片的内容。

## 照片目录

照片不要全部放在一个大文件夹里。默认按事件日期先分年、再分月归档：

```text
photos/YYYY/MM/
```

示例：

```text
photos/2026/08/20260802_6M12D_first-watermelon_baby_happy_P202608020001.jpg
```

原始未处理文件也按年月暂存，避免 `originals` 长期堆成一个大目录：

```text
photos/originals/2026/08/
```

处理完成后复制或移动到年月目录。照片资产库同时记录原始文件名、归档文件名和相对路径。

## Excel 点击照片

Excel 中每张照片资产记录保留：

- `相对路径`
- `查看照片`

`查看照片` 使用公式：

```excel
=HYPERLINK([@相对路径],"查看照片")
```

或者普通单元格公式：

```excel
=HYPERLINK("photos/2026/08/20260802_6M12D_first-watermelon_baby_happy_P202608020001.jpg","查看照片")
```

只要 `ChildGrowthOS.xlsx` 和 `photos/` 文件夹保持相对位置不变，点击即可打开本地图片。Excel 可能弹出安全确认，这是正常行为。

## 事件表如何挂照片

所有事件表不直接存图片，而是存照片资产 ID 和首图路径。

例如 `成长时间轴`：

- `关联照片IDs`：`P202608020001;P202608020003`
- `首图相对路径`：`photos/2026/08/20260802_6M12D_first-watermelon_baby_happy_P202608020001.jpg`
- `查看首图`：`=HYPERLINK([@首图相对路径],"查看首图")`

这样既能从照片资产库查所有照片，也能在某个事件里直接点开相关图片。

## 同步模式

## 微信消息日期与去重

微信渠道的消息可能延迟、重放，或者 Agent 隔天才处理。Local Lite 也必须保存：

- `微信消息ID`
- `微信发送时间`
- `Agent执行时间`
- `记录归属日期`
- `去重键`
- `重复检测状态`

`今天/昨天/明天` 必须按 `微信发送时间` 解释。不要把昨天晚上发来的“今天宝宝……”写到 Agent 今天运行日期。

如果 `去重键` 已存在且写入状态已完成，跳过重复写入，只回复用户这条消息已记录过。

## 待办提醒

本地版也应有 `育儿待办提醒` 工作表和 `data/todos.jsonl`。

典型待办：

- 买奶粉、尿片、湿巾、宝宝衣服。
- 预约疫苗、体检、医生复查。
- 根据知识推送观察 1-2 天大便、睡眠、皮肤反应。
- 出行前准备物品。

相对时间如“明天提醒一下”必须按微信发送时间计算。

### local_only

只写本地 Excel、JSONL 和照片文件夹。适合小白用户。

### feishu_only

只写飞书多维表格。适合懂配置、有协作需求的用户。

### dual_backup

先写本地，成功后同步飞书。飞书失败不影响本地记录。

推荐默认：

```text
local_only -> 用户确认后开启 feishu_sync -> dual_backup
```

## HTML 时间轴预留

后续可由 Agent 读取：

- `data/daily-journal.jsonl`
- `data/photo-assets.jsonl`
- `data/milestones.jsonl`

生成：

```text
exports/html-timeline/index.html
```

时间轴应支持：

- 按年份/月龄浏览。
- 按事件类型筛选：第一次、健康、旅行、喂养、亲子。
- 照片瀑布流或卡片展示。
- 每日成长故事。
- 本地相对路径图片引用，整个文件夹可打包分享。
