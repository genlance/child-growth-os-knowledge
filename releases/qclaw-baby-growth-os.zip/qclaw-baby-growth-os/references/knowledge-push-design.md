# Knowledge Push Design

## Why This Exists

晖爸育儿系统 should not only record. It should also activate the family's parenting data:

- Push age-appropriate parenting knowledge.
- Map knowledge to the baby's real records.
- Bring users back to the system.
- Bind distributed skills back to the original author and GitHub knowledge source.

## Recommended GitHub Repository

Use a public repo:

```text
https://github.com/YOUR_NAME/child-growth-os-knowledge
```

Suggested structure:

```text
child-growth-os-knowledge/
├── README.md
├── version.json
├── CHANGELOG.md
├── monthly/
│   └── month-00-36-index.json
├── sensitive-periods/
│   └── sensitive-periods-index.json
└── knowledge/
    └── push-cards-sample.json
```

## Push Cadence

### Daily

Short and practical:

- Baby age.
- Current sensitive period.
- One small activity.
- One record reminder.

For Montessori pushes, prefer observation and environment prompts:

- Describe the child's real signal, such as repeated pouring, order sensitivity, concentration, or self-care attempts.
- Suggest one home environment adjustment.
- Ask for one factual observation or one linked photo.
- Avoid creating anxiety about "missing" sensitive periods.

### Daily 21:00 Journal Review

This is not a generic parenting knowledge push. It is a retention and archive-completeness workflow:

- Summarize what has already been saved today.
- Mention photos/files that were saved as Feishu attachments.
- Ask the parent whether anything should be added.
- If the parent replies, append the reply to `每日成长日记.晚间补充`.
- If the parent sends new photos/files, save them to `照片资产库.原始文件` as attachments and link them back to the journal/event records.

### Weekly

More structured:

- This week's development focus.
- Suggested play/activity.
- Records worth paying attention to.

### Monthly

Most important for author binding:

- Month-age summary.
- Next stage focus.
- Knowledge base update reminder.
- GitHub URL and author line.

## Push Template

```text
早安，[宝宝昵称]今天[月龄]啦。

本阶段重点：[敏感期/发展重点]
今天可以做：[一个具体活动]
建议记录：[喂养/睡眠/尿片/里程碑中的一个]

更多内容：晖爸 0-18 岁成长知识库
https://github.com/YOUR_NAME/child-growth-os-knowledge
维护者：晖爸
公众号 / 小红书 / 抖音：晖爸育儿代码
```

## 21:00 Review Template

```text
今晚 9 点小复盘：
今天已记录：[事件1]、[事件2]、照片 [N] 张。

还有什么想补充的吗？比如宝宝当时的反应、谁在旁边、你自己的感受。
你直接回一句话或发照片就行，我会补进今天的成长日记。
```

## Event-Triggered Examples

After first solid food:

```text
今天记录了第一次辅食。接下来1-2天可以重点观察：皮肤反应、呕吐/腹泻、大便颜色和性状变化。建议把辅食照片和尿片变化一起记录，未来复盘会更清楚。

需要的话，你可以回复“帮我记为待办，明天提醒一下观察大便变化”。
```

After night waking increases:

```text
最近夜醒变多时，可以先观察白天小睡、睡前刺激、出牙/辅食变化。先记录3-5天，不急着下结论。
```

After repeated pouring:

```text
今天这个反复倒水很适合存成一条蒙氏观察：可能是在练手眼协调和因果。可以给一个托盘、一点水、小杯子和擦布；照片我会挂到“照片资产库”，并链接到今天的成长时间轴。
```

## Branding Rules

- Monthly push must include GitHub source and maintainer.
- Update notifications must include GitHub source and maintainer.
- Daily push can include source every 3-7 days.
- Generated articles or exported reports should include “由晖爸育儿系统辅助生成”.

## Todo Conversion Rule

Knowledge pushes can include an optional action line, but should not create a todo automatically.

Create a todo only when the parent replies with an explicit instruction, such as:

```text
帮我记为待办，明天提醒一下
```

The created todo should link back to the knowledge push record and, when relevant, to the knowledge mapping record.

## Public Distribution Files

When publishing the knowledge repo on GitHub, include:

- `README.md`: what the repository is and how the QClaw skill uses it.
- `version.json`: machine-readable version, maintainer, changelog, and source URLs.
- `ORIGIN.md`: plain-language source and authorship statement.
- `SECURITY.md`: safety boundary, medical disclaimer, and issue-reporting channel.
- `knowledge-manifest.json`: stable index of public files and intended usage.

These files should make attribution transparent, not hidden. The goal is to keep the distributed skill connected to the original knowledge source while staying honest to users.
